<?php
$RESEND_API_KEY = "re_fTujWKwg_2yy9juGsSUxwxGNz3gQdEMHL";
