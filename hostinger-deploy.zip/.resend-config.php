<?php
// Hostinger Private Configuration (Excluded from Git)
$RESEND_API_KEY = 're_BjXB4HmA_PhD81UHTGKXLcwuWd1KVc4y6';
